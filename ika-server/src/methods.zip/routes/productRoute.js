import express from 'express'
import { getAllProducts, createProduct, getAllProductsPagenet } from '../methods/productMethod.js'

const router = express.Router()


router
    .get('/', getAllProducts)
    .post('/', createProduct)
    .get('/:page/:limit', getAllProductsPagenet)

export const PRODUCT_ROUTER = {
    router
}