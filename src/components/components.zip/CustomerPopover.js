import React, {Fragment, useEffect} from 'react'
import { Popover, Transition } from '@headlessui/react'
import {
    BookmarkAltIcon,
    CalendarIcon,
    ChartBarIcon,
    CursorClickIcon,
    MenuIcon,
    PhoneIcon,
    PlayIcon,
    RefreshIcon,
    ShieldCheckIcon,
    SupportIcon,
    ViewGridIcon,
    ChevronDownIcon,
    XIcon,
  } from '@heroicons/react/outline'
  import axios from 'axios'
import { useDispatch, useSelector } from 'react-redux'
import { selectProducts, setProducts, setSelectedProduct } from '../app/slices/productSlice'
import { selectCustomers, setSelectedCustomer } from '../app/slices/customerSlice'
  
function classNames(...classes) {
    return classes.filter(Boolean).join(' ')
  }

const CustomerPopover = ({search, setSearch, product, customer, setCustomer}) => {
    const dispatch = useDispatch()
    const products = useSelector(selectProducts)
    const customers = useSelector(selectCustomers)
    useEffect(async() => {
        const { data  } = await axios.get('/api/product')
        dispatch(setProducts(data))
    },[])
    return (
        <>
            <Popover.Group>
            <Popover className="relative">
              {({ open }) => (
                <>
                  <Popover.Button
                    className={classNames(
                      open ? 'text-pos_color-green' : 'text-pos_color',
                      'group rounded-md inline-flex items-center text-base font-medium hover:text-pos_color-green focus:outline-none focus:ring-0'
                    )}
                  >
                    <ChevronDownIcon
                      className={classNames(
                        open ? 'text-gray-600' : 'text-gray-400',
                        ' h-3 w-3 group-hover:text-gray-500'
                      )}
                      aria-hidden="true"
                    />
                  </Popover.Button>

                  <Transition
                    as={Fragment}
                    enter="transition ease-out duration-200"
                    enterFrom="opacity-0 translate-y-1"
                    enterTo="opacity-100 translate-y-0"
                    leave="transition ease-in duration-150"
                    leaveFrom="opacity-100 translate-y-0"
                    leaveTo="opacity-0 translate-y-1"
                  >
                    <Popover.Panel className="absolute z-10 left-1/2 transform -translate-x-1/2 mt-3 px-2 w-screen max-w-md sm:px-0">
                      <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                        {
                            product ?
                       
                            <div className="relative grid gap-2 bg-white px-5 py-6 sm:gap-8 sm:p-8">

                                <div
                                    className='bg-gray-100 rounded-full shadow'
                                >
                                    <input 
                                        type="text" 
                                        value={search}
                                        onChange={e =>setSearch(e.target.value)}
                                        placeholder='Search by SKU/UPC or Name'
                                        className='border-0 bg-transparent w-full rounded-full
                                            outline-none hover:ring-0
                                        '
                                    />
                                </div>
                                {
                                    products?.length > 0 &&
                                    products?.filter(item => {
                                        if(search === '') {
                                            return item
                                        }else if(item.productName?.toLowerCase()?.includes(search?.toLowerCase())){
                                            return item
                                        }else if(item.SKU_UPC?.includes(search)) return item

                                    }).map((item) => (
                                        <a
                                        key={item._id}
                                        // href={item.href}
                                        onClick={() =>(
                                            setSearch(''),
                                            dispatch(setSelectedProduct(item))
                                        )}
                                        className="-m-3 p-1 flex items-start rounded-lg hover:bg-gray-50"
                                        >
                                        {/* <item.icon className="flex-shrink-0 h-6 w-6 text-indigo-600" aria-hidden="true" /> */}
                                        <div className="ml-4">
                                            <p className="text-base font-medium text-gray-900 cursor-pointer">{item.productName}</p>
                                            <p className="mt-1 text-sm text-gray-500 cursor-pointer">{item.SKU_UPC}</p>
                                        </div>
                                        </a>
                                    ))
                                }
                                
                            </div>
                            :
                            <div className="relative grid gap-2 bg-white px-5 py-6 sm:gap-8 sm:p-8">

                                <div
                                    className='bg-gray-100 rounded-full shadow'
                                >
                                    <input 
                                        type="text" 
                                        value={customer}
                                        onChange={e =>setCustomer(e.target.value)}
                                        placeholder='Search by name'
                                        className='border-0 bg-transparent w-full rounded-full
                                            outline-none hover:ring-0
                                        '
                                    />
                                </div>
                           
                                {
                                    customers?.length > 0 &&
                                    customers?.filter(item => {
                                        if(customer == '') {
                                            return item
                                        }else if(item.firstName?.includes(customer)){
                                            return item
                                        }else if(item.lastName?.includes(customer)) return item

                                    }).map((item) => (
                                        <a
                                        key={item._id}
                                        // href={item.href}
                                        onClick={() =>(
                                            dispatch(setSelectedCustomer(item)),
                                            setCustomer(`${item.firstName}`)
                                        )}
                                        className="-m-3 p-1 flex items-start rounded-lg hover:bg-gray-50"
                                        >
                                        {/* <item.icon className="flex-shrink-0 h-6 w-6 text-indigo-600" aria-hidden="true" /> */}
                                        <div className="ml-4">
                                            <p className="text-base font-medium text-gray-900 cursor-pointer">{`${item.firstName} ${item.lastName}`}</p>
                                            {/* <p className="mt-1 text-sm text-gray-500 cursor-pointer">{item.phoneNumber}</p> */}
                                        </div>
                                        </a>
                                    ))
                                }
                            </div>
                        }
                      </div>
                    </Popover.Panel>
                  </Transition>
                </>
              )}
            </Popover>
            </Popover.Group>
        </>

    )
}

export default CustomerPopover
