import { DotsCircleHorizontalIcon } from '@heroicons/react/outline'
import { PencilAltIcon } from '@heroicons/react/solid'
import { IconButton } from '@mui/material'
import React, { Fragment } from 'react'
import { useDispatch } from 'react-redux'
import { setSelectedProduct } from '../app/slices/productSlice'

const ProductTable = ({search, setIsAdd, products}) => {
    const dispatch = useDispatch()
  return (
        <Fragment>
           
            <table
                className='table w-full'
            >
                <thead>
                    <th className='text-sm'>S/N</th>
                    <th className='text-sm'>SKU/UPC</th>
                    <th className='text-sm'>Product Name</th>
                    <th className='text-sm'>Category</th>
                    <th className='text-sm'>Sub-Category</th>
                    <th className='text-sm'>Qty</th>
                    <th className='text-sm'>Purchase Price (<strike>N</strike>)</th>
                    <th className='text-sm'>Sales Price (<strike>N</strike>)</th>
                    <th></th>
                </thead>

                <tbody>
                    {
                        products?.length > 0 &&
                        products?.filter(item =>{
                            if(search == '' ){
                                return item
                            }else if(item.SKU_UPC?.toString()?.includes(search)) {
                                return item
                            }else if(item.productName?.toLowerCase()?.includes(search?.toLowerCase())){
                                return item
                            }else if(item.purchasePrice?.toString()?.includes(search?.toLowerCase())){
                                return item
                            }else if(item.salesPrice?.toString()?.includes(search?.toLowerCase())){
                                return item
                            }
                        })
                        .map((items, index) => {
                            const { SKU_UPC, category, subCategory, purchasePrice, salesPrice, productName, quantity} = items

                            return(
                                <Fragment
                                    key={index*876}
                                >
                                    <tr
                                        className={ index % 2 ? 'bg-gray-100' : 'bg-white'}
                                    >
                                        <td className='cursor-default text-sm text-center text-pos_color-green'> {index+1} </td>
                                        <td className='cursor-default text-sm text-center'> {SKU_UPC} </td>
                                        <td className='cursor-default text-sm text-center'> {productName} </td>
                                        <td className='cursor-default text-sm text-center'> {category?.name} </td>
                                        <td className='cursor-default text-sm text-center'> {subCategory?.name} </td>
                                        <td className='cursor-default text-sm text-center'> {quantity} </td>
                                        <td className='cursor-default text-sm text-center text-red-500'> 
                                            {purchasePrice?.toLocaleString()} 
                                        </td>
                                        <td className='cursor-default text-sm text-center text-pos_color-green'> 
                                            {salesPrice?.toLocaleString()} 
                                        </td>
                                        <td className='cursor-default text-sm text-center'>
                                            <div>
                                                <IconButton
                                                    size='small'
                                                    onClick={() =>(
                                                        setIsAdd(),
                                                        dispatch(setSelectedProduct(items)) 
                                                    )}
                                                >
                                                    <PencilAltIcon className='w-6' />
                                                </IconButton>
                                            </div>
                                        </td>
                                    </tr>
                                </Fragment>
                            )
                        })
                    }
                </tbody>

            </table>
        </Fragment>
  )
}

export default ProductTable