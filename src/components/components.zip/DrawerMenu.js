import React, { Fragment } from 'react'
import DrawerList from './DrawerList'
import router from 'next/router'
import {
    UsersIcon,
    UserGroupIcon,
    ShoppingBagIcon,
    ClockIcon
} from '@heroicons/react/outline'
import { HomeIcon, ShoppingCartIcon } from '@heroicons/react/solid'
import { useSelector } from 'react-redux'
import { selectUser } from '../app/slices/userSlice'

const DrawerMenu = () => {
    const user = useSelector(selectUser)
    return (
        <section>
            {
                user?.role?.manager == true ?
            <DrawerList 
                title='Home'
                func={ () =>router.push('/home')}
                icon={<HomeIcon className='h-6 text-pos_color' />}
            />
            : null
            }
            <DrawerList 
                title='Sales'
                func={ () =>router.push('/dashboard')}
                icon={<ShoppingCartIcon className='h-6 text-pos_color' />}
            />
            {
                user?.role?.staff == true || user?.role?.manager == true ?
            
                <Fragment>
                    <DrawerList 
                        title='Staffs'
                        func={ () =>router.push('/staff')}
                        icon={<UsersIcon className='h-6 text-pos_color' />}
                    />
                    <DrawerList 
                        title='Report'
                        func={ () =>router.push('/reports')}
                        icon={<ClockIcon className='h-6 text-pos_color'  />}
                    />
                    {
                        user?.role?.manager == true ?
                    
                    <DrawerList 
                        title='Products'
                        func={ () =>router.push('/products')}
                        icon={<ShoppingBagIcon className='h-6 text-pos_color'  />}
                    />
                    :null
                    }
                </Fragment>
                :null
            }
            <DrawerList 
                title='Customers & Vendors'
                func={ () =>router.push('/customer')}
                icon={<UserGroupIcon className='h-6 text-pos_color'  />}
            />
        </section>
    )
}

export default DrawerMenu
