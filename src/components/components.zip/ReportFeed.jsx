import React, { Fragment, useState } from 'react'
import DrawerMenu from './DrawerMenu'
import {withSessionSsr} from '../util/withSession'
import axios from 'axios'
import { useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { selectError, selectIsLoading, selectSuccess, setError, setIsLoading, setSuccess } from '../app/slices/uiSlice'
import { useSelector } from 'react-redux'
import ProductTable from './ProductTable'
import { BadgeCheckIcon, BookOpenIcon, PlusCircleIcon, ShoppingBagIcon, ShoppingCartIcon, TagIcon, XCircleIcon, XIcon } from '@heroicons/react/solid'
import { Button, IconButton } from '@mui/material'
import { addCategory } from '../appHooks/categoryHook'
import { getOrderReport } from '../appHooks/orderHook'
import OrderList from './OrderList'

const ProductFeed = () => {
    const dispatch = useDispatch()
    const Error = useSelector(selectError)
    const success = useSelector(selectSuccess)
    const [add, setAdd] = useState('product')
    const [search, setSearch] = useState('')
    const [isAdd, setIsAdd] = useState('')
   
    const [products, setProducts] = useState([])
   
    
  
   
    return (
        <Fragment>
            <main className='grid grid-cols-1 md:grid-cols-2
            md: max-w-3xl xl:grid-cols-7 xl:max-w-[95%] mx-auto shadow-md px-0 h-[85%]'>
            <div className='hidden xl:inline-grid col-span-1 overflow-auto scrollbar-none px-0 h-full bg-white'
            >
                <DrawerMenu />
                {/* <PostingAnalysis /> */}
            </div>
           
            <section className="col-span-6 overflow-y-auto pb-20 h-[100%] overflow-auto scrollbar-none">
                <div className='flex items-center flex-col justify-center w-full
                    py-2
                '
                >
                    <h1
                        className='text-pos_color font-bold text-2xl'
                    >REPORTS</h1>
                    <section className=' transition-all duration-150 md:w-[95%] sm:w-[90%] mx-auto px-2 py-2 mt-4'>
                        <div
                            className='flex justify-between gap-2'
                        >
                            <Button
                                onClick={() => getOrderReport('/api/orders', dispatch)}
                                className='bg-pos_color text-white px-10 shadow-md hover:shadow-lg'
                            >All <TagIcon className='w-6' /> </Button>
                             <Button
                                onClick={() => getOrderReport('/api/orders/sales', dispatch)}
                                className='bg-pos_color-green text-white px-10 shadow-md hover:shadow-lg'
                            >Sales <ShoppingCartIcon className='w-6' /> </Button>
                             <Button
                                onClick={() => getOrderReport('/api/orders/purchase', dispatch)}
                                className='bg-pos_color text-white px-10 shadow-md hover:shadow-lg'
                            >Purchase <ShoppingBagIcon className='w-6' /> </Button>

                            <Button
                                onClick={() => getOrderReport('/api/orders/open', dispatch)}
                                className='bg-[orange] text-white px-10 shadow-md hover:shadow-lg'
                            >Open <BookOpenIcon className='w-6' /> </Button>
                             <Button
                                onClick={() => getOrderReport('/api/orders/paid', dispatch)}
                                className='bg-pos_color text-white px-10 shadow-md hover:shadow-lg'
                            >Paid <BadgeCheckIcon className='w-6'/> </Button>
                        </div>
                    </section>
                   <main className=' transition-all duration-150 md:w-[95%] sm:w-[95%] mx-auto px-2 py-2 mt-4'>
                        {
                            products &&
                            <Fragment>
                                <div
                                    className='flex justify-between items-center py-2'                                
                                >
                                   <h3
                                        className='font-semibold text-xl flex-1'   
                                    >Report List</h3>
                                    

                                </div>
                                <OrderList 
                                    search={search}
                                    products={products}  
                                /> 
                            </Fragment>
                            
                        }
                   </main>
                </div>
                
                
            </section>

           
        </main>
        </Fragment>
    )
}



export default ProductFeed
