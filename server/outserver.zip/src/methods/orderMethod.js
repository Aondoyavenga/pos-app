import { Order } from "../models/Order.js"
import { Orderitem } from "../models/OrderItems.js"
import { Product } from "../models/Product.js"

export const getSalesOrders = async(req, res) => {
    try {
        const data = await Order.find({orderType: 'SALE'})
        .populate('customerRef', {__v: 0, updatedAt: 0})
        .populate('userRef', {__v: 0, updatedAt: 0, password: 0}).sort({updatedAt: -1})
        res.json(data)
    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}

export const getPurchasesOrders = async(req, res) => {
    try {
        const data = await Order.find({orderType: 'PURCHASE'}) 
        .populate('customerRef', {__v: 0, updatedAt: 0})
        .populate('userRef', {__v: 0, updatedAt: 0, password: 0}).sort({updatedAt: -1})
        res.json(data)
    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}

export const getOrderByStatus = async(req, res) => {
    try {
        const {status}= req.params
        const data = await Order.find({status})
        .populate('customerRef', {__v: 0, updatedAt: 0})
        .populate('userRef', {__v: 0, updatedAt: 0, password: 0}).sort({updatedAt: -1})
        res.json(data)
    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}
export const getCustomerOrders = async (req, res) =>{
    try {
        const {orderId} = req.params
        const custId = await Order.findOne({orderId}).select({customerRef: 1})
        if(!custId) return res.status(404).send({message: `Please enter valid sale id`})

        const orders = await Order.find({customerRef: custId?.customerRef})
        .populate('customerRef', {__v: 0, updatedAt: 0})
        res.send(orders)
    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}

export const getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find({status:{$ne: 'Void'}}).select({__v: 0, updatedAt: 0})
        .populate('customerRef', {__v: 0, updatedAt: 0})
        .populate('userRef', {__v: 0, updatedAt: 0, password: 0}).sort({updatedAt: -1})

        
        res.send(orders)

    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}

export const getAllOrderItems = async (req, res) => {
    try {
        
        const items = await Orderitem.find({})
        res.json(items)
    } catch (error) {
        console.log(error)
        res.status(404).send({message: `${error.message} Internal Server Error`})
    }
}

export const getOrderItems = async(req, res) => {
    try {
        const {orderId} = req.params
        const items = await Orderitem.find({orderId}).select({__v: 0, updatedAt: 0})
        .populate('productRef', {__v: 0, updatedAt: 0})
        res.send(items)
    } catch (error) {
        res.status(404).send({message: `Internal Server Error`})
    }
}

const handleUpdateProduct = async(id, type, qty) => {
    const product = await Product.findById(id)
    return await product.updateQty(id, type, qty)
}

const handleUpdateOrderItem = async(item, next) => {
   try {
    const {quantity, orderType, productRef, orderRow} = item
    // console.log(productRef)

    // const newitem = new Orderitem({...item})
    // if(orderItem?.orderRow) return Orderitem.findByIdAndUpdate(orderItem?._id, {$set: {...item}})
        // handleUpdateProduct(productRef, orderType, quantity)
    Orderitem.create({...item}, async(err, result) =>{
        
        if(err) {
            const orderItem = await Orderitem.find({orderRow})

            const qty = quantity > orderItem?.quantity ? quantity - orderItem?.quantity : quantity < orderItem.quantity ? orderItem.quantity - quantity :0
            const type = orderType == 'PURCHASE' && quantity < orderItem?.quantity ? 'SALE': item?.orderType
            
            await Orderitem.findOneAndUpdate(orderRow, {$set: {...item}})
            
           
            return handleUpdateProduct(productRef, type, qty )
        }

        handleUpdateProduct(productRef, orderType, quantity)

    })
    
   } catch (error) {
       next(error.message)
   }
        
}

export const removeOrderItem = async (req, res) => {
    try {
        const {orderRow} = req.params
       const isDelete =  await Orderitem.deleteOne({orderRow})
        
        res.send({message: 'Row Removed'})
    } catch (error) {
        return res.status(404).send({message: `${error.message} Internal Server Error`})
    }
}

export const removeOrder = async (req, res) => {
    try {
        const {orderId} = req.params
        await Order.findOneAndUpdate({orderId}, {$set: {status: 'Void'}})
        
        await Orderitem.updateMany({orderId}, {$set: {status: 'Void'}})
        res.status(201).send({message: `#${orderId} Order deleted successful`})

    } catch (error) {
        return res.status(404).send({message: `${error.message} Internal Server Error`})
    }
}

export const placeOrder = async (req, res, next) => {
    try {
        const { orderId, status,orderType, payment, customerRef, userRef, amount, totalPaid, orderOn, VALUES } = req.body
        const newOder = new Order({orderId, status, orderOn, orderType, customerRef, userRef, amount, totalPaid, payment})
        if(!orderType || !customerRef || !userRef || !amount || !VALUES?.length > 0) return res.status(404).send({message: 'Invalid request'})
        const error = newOder.validateSync()
        if (error && error.message) return res.status(404).send({message: error.message.split(':')[2].split(',')[0]});

    
        // const {updatedAt} = await newOder.save()
        await Order.findOneAndUpdate({orderId}, {status, orderOn, orderType, customerRef, userRef, amount, totalPaid, payment}, {upsert:true})
           
            VALUES.map(item =>{
                const {productRef, quantity, orderType} = item
                const qty = parseInt(quantity)
                // handleUpdateProduct(productRef, orderType, qty)
                handleUpdateOrderItem(item)
            });
        
        res.status(201).send({message: `Order successful`})
    } catch (error) {
        
        return res.status(404).send({message: `Internal Server Error`})
    }
}
