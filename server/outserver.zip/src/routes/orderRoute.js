import express from 'express'
import { getAllOrders, placeOrder, getOrderItems, removeOrderItem, getCustomerOrders, getAllOrderItems, getSalesOrders, getPurchasesOrders, getOrderByStatus, removeOrder } from '../methods/orderMethod.js'
const router = express.Router()

router
    .get('/', getAllOrders)
    .get('/:orderId', getCustomerOrders)
    .get('/items/:orderId', getOrderItems)
    .get('/list/all', getAllOrderItems)
    .get('/ordertype/sales', getSalesOrders)
    .get('/ordertype/purchase', getPurchasesOrders)
    .get('/orderstatus/:status', getOrderByStatus)

    .post('/', placeOrder)
    .delete('/:orderId', removeOrder)
    .delete('/row/:orderRow', removeOrderItem)

export const ORDER_ROUTER = {
    router
}