import express from 'express'
import { getAllProducts, createProduct } from '../methods/productMethod.js'

const router = express.Router()


router
    .get('/', getAllProducts)
    .post('/', createProduct)

export const PRODUCT_ROUTER = {
    router
}